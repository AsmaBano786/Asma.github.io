# Buy-N-Sell

Minor Project - "Buy N Sell" 
Description - “BUY AND SELL DURING THIS PANDEMIC BY SITTING AT YOUR HOME”. 
Buy N Sell is actually a web application in which the user can Buy the products with special discounts and also they can Sell their items if they want to do so with higher profit rates. This project is made by using HTML, CSS, Javascript, Bootstrap, PHP, SQL, MySQL database. This web application is actually very helpful for those business personalities who are generally facing high loss during this pandemic.
